# CacosGPiCASE2Script

A replacement for the officical [GPiCase2-Script](https://github.com/RetroFlag/GPiCase2-Script), for use with [Recalbox 8.0.x](https://www.recalbox.com/) only.

I had too much trouble with the original one. Therefore I wrote this more robust and simpler to use replacement. it still performs a full reboot after connecting to or disconnecting from the docking station.

## Installation instructions

1. Connect your GPiCase2 to your WiFi
2. Login via SSH (The default passwort is **recalboxroot**)

```sh
ssh root@recalbox
```

2. Download the script as ZIP container via wget: 

```sh
wget -O /tmp/CacosGPiCASE2_Script.zip https://github.com/Cacodaimon/CacosGPiCASE2Script/blob/main/CacosGPiCASE2_Script.zip?raw=true
```

3. Install the script using the self install function

```sh
python /tmp/CacosGPiCASE2_Script.zip --setup
```

4. Reboot your GPiCase2

```sh
shutdown -r now
```

## Other useful comamnd

### Install display config files

This script comes with the both original Display Patch files (`config_lcd.txt` and `config_hdmi.txt`) from RetroFlag, you can install them using the following command:

```sh
python /tmp/CacosGPiCASE2_Script.zip --create_config_files
```

### Testing without installation

Once downloaded cia `wget` you can test the script without installation, you might download it again after reboot:

```sh
python /tmp/CacosGPiCASE2_Script.zip --wait_for_changes --reboot
```

### Force HDMI or LCD


```sh
python /tmp/CacosGPiCASE2_Script.zip --set_lcd|--set_hdmi
```

## Uninstall


1. Login via SSH (The default passwort is **recalboxroot**)

```sh
ssh root@recalbox
```

2. Delete the both files:

```sh
rm /etc/init.d/S99CacosGPiCase2Script
rm /opt/cacos_gpicase2_script.zip
```

3. Reboot your GPiCase2

```sh
shutdown -r now
```