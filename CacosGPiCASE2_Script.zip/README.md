# CacosGPiCASE2Script

A replacement for the officical [GPiCase2-Script](https://github.com/RetroFlag/GPiCase2-Script), for use with [Recalbox 8.0.x](https://www.recalbox.com/) only.



## Installation instruction

1. Connect your GPiCase2 to your WiFi
2. Download the script as ZIP container via wget: 

```sh
wget -O CacosGPiCASE2Script.zip https://github.com/Cacodaimon/CacosGPiCASE2Script/archive/refs/heads/main.zip
```

3. 